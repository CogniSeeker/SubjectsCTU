dq = daq("ni");
dq.Rate = 1000;

% inputs (same as before) ...
% addinput(...)

% add digital output for conveyor enable
do = addoutput(dq, "Dev1", "port1/line3", "Digital");  % adjust line
write(dq, true);   % conveyor ON
start(dq, "continuous");  % start reading
...
write(dq, false);  % conveyor OFF
stop(dq);
