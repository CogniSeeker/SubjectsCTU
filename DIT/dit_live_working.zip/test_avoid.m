u = udpport("datagram","IPV4","LocalPort",5005);
buf = timetable();

while true
    if u.NumDatagramsAvailable > 0
        d = read(u, u.NumDatagramsAvailable, "double"); % depends on how you pack
        % unpack -> time + channels
        % append to buf and run same GUI update logic
    end
    pause(0.01);
end
