function out = classify_at_times(ev, p)
%CLASSIFY_AT_TIMES Fuse residual fires in time and classify fault at each alarm time.

p = conveyor_alarm_defaults(p);

% Candidate times = all firing instants (union)
t = unique([ ...
    ev.tick.t_s(ev.tick.fire); ...
    ev.trav.t_s(ev.trav.fire); ...
    ev.dir.t_s(ev.dir.fire);  ...
    ev.io_L1.t_s(ev.io_L1.fire); ...
    ev.io_L2.t_s(ev.io_L2.fire); ...
    ev.io_pair.t_s(ev.io_pair.fire); ...
    ev.pwr.t_s(ev.pwr.fire) ...
]);

if isempty(t)
    out = table([], [], [], [], string.empty(0,1), ...
        'VariableNames', {'t_s','tick','trav','dir','class'});
    return;
end

% Helper: active if any fire in (t0-hold_s, t0]
isActive = @(t0, te, fe) any(fe & (te > (t0 - p.hold_s)) & (te <= t0));

tickA = false(size(t));
travA = false(size(t));
dirA  = false(size(t));
ioL1A = false(size(t));
ioL2A = false(size(t));
ioPairA = false(size(t));
pwrA = false(size(t));

for i = 1:numel(t)
    t0 = t(i);
    tickA(i)   = isActive(t0, ev.tick.t_s, ev.tick.fire);
    travA(i)   = isActive(t0, ev.trav.t_s, ev.trav.fire);
    dirA(i)    = isActive(t0, ev.dir.t_s,  ev.dir.fire);

    ioL1A(i)   = isActive(t0, ev.io_L1.t_s,   ev.io_L1.fire);
    ioL2A(i)   = isActive(t0, ev.io_L2.t_s,   ev.io_L2.fire);
    ioPairA(i) = isActive(t0, ev.io_pair.t_s, ev.io_pair.fire);

    pwrA(i)    = isActive(t0, ev.pwr.t_s, ev.pwr.fire);
end


cls = repmat("NONE", numel(t), 1);

% Gate: power overrides everything
cls(pwrA) = "GLOBAL_POWER";
np = ~pwrA;

% Lamp evidence dominates (except power)
cls(np & (ioL1A | ioL2A)) = "LAMP_OPEN";

% Sensor misaligned / dirty (IO mismatch + travel anomaly)
cls(np & ioPairA & travA) = "SENSOR_MISALIGNED";

% IO-only mismatch (broken wire / sensor IO issue)
cls(np & ioPairA & ~travA & ~dirA & ~tickA & ~ioL1A & ~ioL2A) = "IO_FAULT";

% H-bridge stuck (direction fault only)
cls(np & dirA & ~tickA & ~travA & ~ioPairA & ~ioL1A & ~ioL2A) = "HBRIDGE_STUCK";

% Mechanical anomaly (tick/travel)
cls(np & ~dirA & (tickA | travA) & ~ioPairA & ~ioL1A & ~ioL2A) = "MECH_ANOMALY";

% Mixed cases
cls(np & dirA & (tickA | travA) & cls=="NONE") = "MULTI_ANOMALY";
cls(np & (ioPairA | ioL1A | ioL2A) & cls=="NONE") = "MIXED_WITH_IO";

% ---- Locking / refractory between different classes (priority-based) ----
prio = containers.Map( ...
    ["GLOBAL_POWER","LAMP_OPEN","LAMP_L1_OPEN","LAMP_L2_OPEN","SENSOR_MISALIGNED","IO_FAULT","HBRIDGE_STUCK","MECH_ANOMALY","MULTI_ANOMALY","MIXED_WITH_IO","NONE"], ...
    [ 100,          90,         90,           90,           80,               70,       60,            50,           40,            30,            0] );

lastClass = "NONE";
lastTime  = -inf;

for i = 1:numel(t)
    c = cls(i);

    if c == "NONE"
        continue;
    end

    if lastClass == "NONE"
        lastClass = c;
        lastTime  = t(i);
        continue;
    end

    dt = t(i) - lastTime;

    % allow switch only if outside refractory OR higher priority
    if dt < p.refractory_s && prio(c) <= prio(lastClass)
        cls(i) = lastClass;  % suppress/snap to previous fault
    else
        lastClass = c;
        lastTime  = t(i);
    end
end


out = table(t, tickA, travA, dirA, ioPairA, ioL1A, ioL2A, pwrA, cls, ...
    'VariableNames', {'t_s','tick','trav','dir','io_pair','io_L1','io_L2','pwr','class'});

end
